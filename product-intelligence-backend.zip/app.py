from flask import Flask
from flask_cors import CORS
from routes.amazon import amazon_bp
from routes.ebay import ebay_bp
from routes.products import products_bp
from routes.auth import auth_bp
import os

app = Flask(__name__)
CORS(app)  # Frontend se connect hone ke liye

# Routes register karo
app.register_blueprint(amazon_bp, url_prefix='/api/amazon')
app.register_blueprint(ebay_bp, url_prefix='/api/ebay')
app.register_blueprint(products_bp, url_prefix='/api/products')
app.register_blueprint(auth_bp, url_prefix='/api/auth')

@app.route('/')
def home():
    return {"status": "running", "message": "Product Intelligence API is live!"}

if __name__ == '__main__':
    app.run(debug=True, port=5000)
