from flask import Blueprint, request, jsonify
from services.ai_scoring import score_product
from services.database import get_db
import requests
import os
from datetime import datetime

ebay_bp = Blueprint('ebay', __name__)

def get_ebay_token():
    """eBay se access token lo"""
    app_id = os.getenv('EBAY_APP_ID')
    secret = os.getenv('EBAY_CLIENT_SECRET')

    if not app_id or not secret:
        return None

    import base64
    credentials = base64.b64encode(f"{app_id}:{secret}".encode()).decode()

    response = requests.post(
        'https://api.ebay.com/identity/v1/oauth2/token',
        headers={
            'Authorization': f'Basic {credentials}',
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        data='grant_type=client_credentials&scope=https://api.ebay.com/oauth/api_scope'
    )

    if response.status_code == 200:
        return response.json().get('access_token')
    return None


def search_ebay_products(keyword: str, count: int = 10):
    """
    eBay Browse API se products search karo
    Real API ya mock data
    """
    token = get_ebay_token()

    if token:
        # Real eBay API call
        response = requests.get(
            'https://api.ebay.com/buy/browse/v1/item_summary/search',
            headers={'Authorization': f'Bearer {token}'},
            params={
                'q': keyword,
                'limit': count,
                'filter': 'buyingOptions:{FIXED_PRICE}'
            }
        )

        if response.status_code == 200:
            items = response.json().get('itemSummaries', [])
            products = []
            for item in items:
                price = float(item.get('price', {}).get('value', 0))
                products.append({
                    'ebay_id': item.get('itemId'),
                    'title': item.get('title'),
                    'price': price,
                    'category': item.get('categories', [{}])[0].get('categoryName', 'general'),
                    'image_url': item.get('image', {}).get('imageUrl', ''),
                    'product_url': item.get('itemWebUrl', ''),
                    'condition': item.get('condition', ''),
                    'sold_count': item.get('soldQuantity', 0),
                    'active_listings': 50,  # eBay Browse API mein nahi hota
                    'review_count': 0,
                    'rating': 0,
                    'bsr': 9999,  # eBay mein BSR nahi hota
                })
            return products

    # Mock data (jab tak API keys nahi hain)
    return [
        {
            'ebay_id': '123456789',
            'title': f'{keyword} - New Arrival Best Price',
            'price': 24.99,
            'category': 'electronics',
            'image_url': 'https://via.placeholder.com/200',
            'product_url': 'https://ebay.com/itm/123456789',
            'condition': 'New',
            'sold_count': 342,
            'active_listings': 89,
            'review_count': 0,
            'rating': 0,
            'bsr': 5000,
        },
        {
            'ebay_id': '987654321',
            'title': f'{keyword} - Fast Shipping Quality Item',
            'price': 34.99,
            'category': 'electronics',
            'image_url': 'https://via.placeholder.com/200',
            'product_url': 'https://ebay.com/itm/987654321',
            'condition': 'New',
            'sold_count': 128,
            'active_listings': 230,
            'review_count': 0,
            'rating': 0,
            'bsr': 8000,
        }
    ]


def calculate_ebay_demand(sold_count: int, active_listings: int) -> float:
    """
    eBay demand ratio: kitne sell ho rahe hain vs active listings
    High ratio = high demand
    """
    if active_listings == 0:
        return 0
    return round(sold_count / active_listings, 2)


@ebay_bp.route('/search', methods=['GET'])
def search():
    """
    eBay product search
    URL: GET /api/ebay/search?keyword=bluetooth+speaker
    """
    keyword = request.args.get('keyword', '')
    if not keyword:
        return jsonify({"error": "keyword parameter required"}), 400

    try:
        raw_products = search_ebay_products(keyword)
        db = get_db()

        results = []
        for product in raw_products:
            # Demand ratio calculate karo
            demand_ratio = calculate_ebay_demand(
                product.get('sold_count', 0),
                product.get('active_listings', 1)
            )

            # AI scores
            scores = score_product(product)

            # eBay ke liye demand boost
            if demand_ratio > 0.5:
                scores['winning_score'] = min(100, scores['winning_score'] + 10)

            # Database mein save karo
            product_result = db.table('products').upsert({
                'platform': 'ebay',
                'external_id': product['ebay_id'],
                'title': product['title'],
                'category': product.get('category', ''),
                'image_url': product.get('image_url', ''),
                'product_url': product.get('product_url', ''),
            }, on_conflict='platform,external_id').execute()

            if product_result.data:
                product_id = product_result.data[0]['id']
                db.table('metrics').upsert({
                    'product_id': product_id,
                    'record_date': datetime.now().date().isoformat(),
                    'price': product.get('price', 0),
                    'est_monthly_sales': scores['est_monthly_sales'],
                    'est_monthly_revenue': scores['est_monthly_revenue'],
                    'competition_score': scores['competition_score'],
                    'roi_estimate': scores['roi_estimate'],
                    'winning_score': scores['winning_score'],
                }, on_conflict='product_id,record_date').execute()

            results.append({
                **product,
                **scores,
                'demand_ratio': demand_ratio,
                'platform': 'ebay'
            })

        results.sort(key=lambda x: x['winning_score'], reverse=True)

        return jsonify({
            "keyword": keyword,
            "platform": "ebay",
            "count": len(results),
            "products": results
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 500
