from flask import Blueprint, request, jsonify
from services.ai_scoring import score_product
from services.database import get_db
import requests
import os
from datetime import datetime

amazon_bp = Blueprint('amazon', __name__)

def search_amazon_products(keyword: str, count: int = 10):
    """
    Amazon Product Advertising API se products search karo
    NOTE: Pehle Amazon Associate account chahiye
    """
    # Amazon PA-API endpoint
    # Abhi mock data return kar raha hai
    # Real API keys milne ke baad yahan asli call hogi

    mock_products = [
        {
            "asin": "B08N5WRWNW",
            "title": f"{keyword} - Premium Quality Product",
            "price": 29.99,
            "bsr": 1250,
            "category": "electronics",
            "review_count": 4823,
            "rating": 4.5,
            "image_url": "https://via.placeholder.com/200",
            "product_url": f"https://amazon.com/dp/B08N5WRWNW",
            "active_listings": 45
        },
        {
            "asin": "B09XY12345",
            "title": f"{keyword} - Best Seller 2024",
            "price": 19.99,
            "bsr": 3200,
            "category": "electronics",
            "review_count": 1205,
            "rating": 4.2,
            "image_url": "https://via.placeholder.com/200",
            "product_url": f"https://amazon.com/dp/B09XY12345",
            "active_listings": 120
        }
    ]
    return mock_products


def save_product_to_db(product_data: dict, scores: dict):
    """Product aur uske scores database mein save karo"""
    db = get_db()

    # Product save karo (agar pehle se hai to update karo)
    product_result = db.table('products').upsert({
        'platform': 'amazon',
        'external_id': product_data['asin'],
        'title': product_data['title'],
        'category': product_data.get('category', ''),
        'image_url': product_data.get('image_url', ''),
        'product_url': product_data.get('product_url', ''),
    }, on_conflict='platform,external_id').execute()

    if not product_result.data:
        return None

    product_id = product_result.data[0]['id']

    # Metrics save karo
    db.table('metrics').upsert({
        'product_id': product_id,
        'record_date': datetime.now().date().isoformat(),
        'price': product_data.get('price', 0),
        'review_count': product_data.get('review_count', 0),
        'rating': product_data.get('rating', 0),
        'bsr': product_data.get('bsr', 0),
        'est_monthly_sales': scores['est_monthly_sales'],
        'est_monthly_revenue': scores['est_monthly_revenue'],
        'virality_score': scores['virality_score'],
        'competition_score': scores['competition_score'],
        'roi_estimate': scores['roi_estimate'],
        'winning_score': scores['winning_score'],
    }, on_conflict='product_id,record_date').execute()

    return product_id


@amazon_bp.route('/search', methods=['GET'])
def search():
    """
    Amazon product search endpoint
    URL: GET /api/amazon/search?keyword=wireless+earbuds
    """
    keyword = request.args.get('keyword', '')
    if not keyword:
        return jsonify({"error": "keyword parameter required"}), 400

    try:
        # Amazon se products fetch karo
        raw_products = search_amazon_products(keyword)

        results = []
        for product in raw_products:
            # AI scores calculate karo
            scores = score_product(product)

            # Database mein save karo
            save_product_to_db(product, scores)

            # Response mein add karo
            results.append({
                **product,
                **scores,
                'platform': 'amazon'
            })

        # Winning score ke basis pe sort karo
        results.sort(key=lambda x: x['winning_score'], reverse=True)

        return jsonify({
            "keyword": keyword,
            "platform": "amazon",
            "count": len(results),
            "products": results
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 500


@amazon_bp.route('/product/<asin>', methods=['GET'])
def get_product(asin: str):
    """
    Specific product ki detail
    URL: GET /api/amazon/product/B08N5WRWNW
    """
    try:
        db = get_db()

        # Database se product dhundo
        result = db.table('products')\
            .select('*, metrics(*)')\
            .eq('platform', 'amazon')\
            .eq('external_id', asin)\
            .execute()

        if not result.data:
            return jsonify({"error": "Product not found"}), 404

        return jsonify(result.data[0])

    except Exception as e:
        return jsonify({"error": str(e)}), 500
