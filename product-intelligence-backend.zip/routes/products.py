from flask import Blueprint, request, jsonify
from services.database import get_db

products_bp = Blueprint('products', __name__)
auth_bp = Blueprint('auth', __name__)

# ============================================
# PRODUCTS ROUTES
# ============================================

@products_bp.route('/top', methods=['GET'])
def get_top_products():
    """
    Top winning products
    URL: GET /api/products/top?platform=amazon&limit=10
    """
    platform = request.args.get('platform', 'all')
    limit = int(request.args.get('limit', 10))

    try:
        db = get_db()

        query = db.table('product_latest_metrics').select('*')

        if platform != 'all':
            query = query.eq('platform', platform)

        result = query.order('winning_score', desc=True).limit(limit).execute()

        return jsonify({
            "platform": platform,
            "count": len(result.data),
            "products": result.data
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@products_bp.route('/search', methods=['GET'])
def search_all():
    """
    Dono platforms pe ek saath search
    URL: GET /api/products/search?keyword=earbuds
    """
    keyword = request.args.get('keyword', '')
    if not keyword:
        return jsonify({"error": "keyword required"}), 400

    try:
        db = get_db()

        # Database mein title se search karo
        result = db.table('product_latest_metrics')\
            .select('*')\
            .ilike('title', f'%{keyword}%')\
            .order('winning_score', desc=True)\
            .limit(20)\
            .execute()

        return jsonify({
            "keyword": keyword,
            "count": len(result.data),
            "products": result.data
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@products_bp.route('/alerts', methods=['POST'])
def create_alert():
    """
    Alert set karo
    URL: POST /api/products/alerts
    Body: {"user_id": "...", "product_id": "...", "condition": "price_below", "threshold": 20}
    """
    data = request.json
    try:
        db = get_db()
        result = db.table('alerts').insert({
            'user_id': data['user_id'],
            'product_id': data['product_id'],
            'condition': data['condition'],
            'threshold': data.get('threshold', 0),
        }).execute()

        return jsonify({"success": True, "alert": result.data[0]})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ============================================
# AUTH ROUTES
# ============================================

@auth_bp.route('/register', methods=['POST'])
def register():
    """
    User register karo
    URL: POST /api/auth/register
    Body: {"email": "...", "password": "..."}
    """
    data = request.json
    email = data.get('email')
    password = data.get('password')

    if not email or not password:
        return jsonify({"error": "Email aur password chahiye"}), 400

    try:
        import bcrypt
        password_hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()

        db = get_db()
        result = db.table('users').insert({
            'email': email,
            'password_hash': password_hash,
            'role': 'free'
        }).execute()

        return jsonify({
            "success": True,
            "message": "Account ban gaya!",
            "user_id": result.data[0]['id']
        })
    except Exception as e:
        if 'duplicate' in str(e).lower():
            return jsonify({"error": "Yeh email pehle se registered hai"}), 409
        return jsonify({"error": str(e)}), 500


@auth_bp.route('/login', methods=['POST'])
def login():
    """
    User login
    URL: POST /api/auth/login
    Body: {"email": "...", "password": "..."}
    """
    data = request.json
    email = data.get('email')
    password = data.get('password')

    try:
        import bcrypt
        import jwt
        import os
        from datetime import datetime, timedelta

        db = get_db()
        result = db.table('users').select('*').eq('email', email).execute()

        if not result.data:
            return jsonify({"error": "Email ya password galat hai"}), 401

        user = result.data[0]

        if not bcrypt.checkpw(password.encode(), user['password_hash'].encode()):
            return jsonify({"error": "Email ya password galat hai"}), 401

        # JWT token banao
        token = jwt.encode({
            'user_id': user['id'],
            'email': user['email'],
            'role': user['role'],
            'exp': datetime.utcnow() + timedelta(days=7)
        }, os.getenv('JWT_SECRET', 'default_secret'), algorithm='HS256')

        return jsonify({
            "success": True,
            "token": token,
            "user": {
                "id": user['id'],
                "email": user['email'],
                "role": user['role']
            }
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500
