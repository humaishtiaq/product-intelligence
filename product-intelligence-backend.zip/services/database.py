from supabase import create_client
import os
from dotenv import load_dotenv

load_dotenv()

# Supabase se connect karo
supabase = create_client(
    os.getenv("SUPABASE_URL"),
    os.getenv("SUPABASE_KEY")
)

def get_db():
    return supabase
