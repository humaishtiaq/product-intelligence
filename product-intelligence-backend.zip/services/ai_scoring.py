import math

# ============================================
# AI SCORING ENGINE
# Yeh formulas executive summary se hain
# ============================================

def calculate_estimated_sales(bsr: int, category: str) -> int:
    """
    Amazon BSR se monthly sales estimate karo
    Formula: EstSales = alpha * e^(-beta * log(BSR))
    """
    # Har category ke liye alag coefficients
    category_coefficients = {
        'electronics':    {'alpha': 3000, 'beta': 0.7},
        'toys':           {'alpha': 2500, 'beta': 0.65},
        'home':           {'alpha': 2000, 'beta': 0.6},
        'clothing':       {'alpha': 4000, 'beta': 0.75},
        'sports':         {'alpha': 1800, 'beta': 0.6},
        'pet_supplies':   {'alpha': 1500, 'beta': 0.55},
        'default':        {'alpha': 2000, 'beta': 0.65},
    }

    cat = category_coefficients.get(category.lower(), category_coefficients['default'])
    alpha = cat['alpha']
    beta = cat['beta']

    if bsr <= 0:
        return 0

    est_sales = alpha * math.exp(-beta * math.log(bsr))
    return max(0, int(est_sales))


def calculate_estimated_revenue(est_sales: int, price: float) -> float:
    """Monthly revenue = sales x price"""
    return round(est_sales * price, 2)


def calculate_virality_score(views: int, likes: int, comments: int, trend_increase: float = 0) -> int:
    """
    TikTok/Social virality score 0-100
    Formula: V = w1*log(views) + w2*log(likes) + w3*log(comments) + w4*trend
    """
    w1, w2, w3, w4 = 0.4, 0.3, 0.2, 0.1

    v = (
        w1 * math.log(views + 1) +
        w2 * math.log(likes + 1) +
        w3 * math.log(comments + 1) +
        w4 * trend_increase
    )

    # Normalize to 0-100 (assuming max log value ~20)
    normalized = min(100, int((v / 20) * 100))
    return normalized


def calculate_competition_score(active_listings: int, avg_daily_sales: float) -> int:
    """
    Competition score 0-100 (zyada = kam competition = acha)
    Formula: C = 100 - 10 * log(1 + listings/sales)
    """
    if avg_daily_sales <= 0:
        avg_daily_sales = 1

    ratio = active_listings / avg_daily_sales
    score = 100 - (10 * math.log(1 + ratio))
    return max(0, min(100, int(score)))


def calculate_roi(price: float, cost: float) -> float:
    """
    ROI percentage
    Formula: ROI = (price - cost) / price * 100
    """
    if price <= 0:
        return 0
    return round(((price - cost) / price) * 100, 2)


def calculate_winning_score(
    est_monthly_sales: int,
    virality_score: int,
    roi_estimate: float,
    competition_score: int,
    review_count: int = 0,
    rating: float = 0
) -> int:
    """
    Final Winning Score 0-100
    Weights: 30% demand, 30% trend, 20% ROI, 20% competition
    """
    # Demand score (sales ke basis pe, max 5000 sales = 100)
    demand_score = min(100, (est_monthly_sales / 5000) * 100)

    # Review bonus (optional)
    review_bonus = min(10, (review_count / 1000) * 10)
    rating_bonus = min(5, (rating / 5) * 5)

    # Weighted final score
    winning = (
        0.30 * demand_score +
        0.30 * virality_score +
        0.20 * roi_estimate +
        0.20 * competition_score +
        review_bonus +
        rating_bonus
    )

    return max(0, min(100, int(winning)))


def score_product(product_data: dict) -> dict:
    """
    Ek product ka pura score calculate karo
    product_data mein yeh fields chahiyein:
    - bsr, category, price, cost
    - active_listings
    - views, likes, comments (TikTok ke liye)
    - review_count, rating
    """
    bsr = product_data.get('bsr', 999999)
    category = product_data.get('category', 'default')
    price = float(product_data.get('price', 0))
    cost = float(product_data.get('cost', price * 0.4))  # default 40% cost
    active_listings = product_data.get('active_listings', 100)
    review_count = product_data.get('review_count', 0)
    rating = float(product_data.get('rating', 0))

    # TikTok data (agar ho)
    views = product_data.get('views', 0)
    likes = product_data.get('likes', 0)
    comments = product_data.get('comments', 0)

    # Sab scores calculate karo
    est_sales = calculate_estimated_sales(bsr, category)
    est_revenue = calculate_estimated_revenue(est_sales, price)
    virality = calculate_virality_score(views, likes, comments)
    avg_daily_sales = est_sales / 30
    competition = calculate_competition_score(active_listings, avg_daily_sales)
    roi = calculate_roi(price, cost)
    winning = calculate_winning_score(est_sales, virality, roi, competition, review_count, rating)

    return {
        'est_monthly_sales': est_sales,
        'est_monthly_revenue': est_revenue,
        'virality_score': virality,
        'competition_score': competition,
        'roi_estimate': roi,
        'winning_score': winning
    }
